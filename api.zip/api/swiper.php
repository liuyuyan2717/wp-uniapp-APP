<?php
	
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers:x-requested-with,content-type'); 
$myObj1->image = "https://cdn.uviewui.com/uview/swiper/1.jpg";
$myObj1->title = '两个月肝爆网络工程师-我的软考笔记';
$myObj2->image = 'https://cdn.uviewui.com/uview/swiper/2.jpg';
$myObj2->title = 'wp+uniapp实现你的全栈梦';
$myObj3->image = 'https://cdn.uviewui.com/uview/swiper/3.jpg';
$myObj3->title = '不知道写啥了，这张是凑数的';
$myObj = array($myObj1,$myObj2,$myObj3);
//$myObj:
		// [{
		// 	image: 'https://cdn.uviewui.com/uview/swiper/1.jpg',
		// 	title: '昨夜星辰昨夜风，画楼西畔桂堂东'
		// },
		// {
		// 	image: 'https://cdn.uviewui.com/uview/swiper/2.jpg',
		// 	title: '身无彩凤双飞翼，心有灵犀一点通'
		// },
		// {
		// 	image: 'https://cdn.uviewui.com/uview/swiper/3.jpg',
		// 	title: '谁念西风独自凉，萧萧黄叶闭疏窗，沉思往事立残阳'
		// }]

//轮播图对应的博客地址
$url1='191';
$url2='191';
$url3='145';

if($_GET['flag']==9){
$myJSON = json_encode($myObj);
}elseif ($_GET['flag']==0) {
$myJSON = json_encode($url1);
}elseif ($_GET['flag']==1) {
$myJSON = json_encode($url2);
}elseif ($_GET['flag']==2) {
$myJSON = json_encode($url3);
};
print_r($myJSON);
?>