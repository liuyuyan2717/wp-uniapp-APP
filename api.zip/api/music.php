<?php
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Headers:x-requested-with,content-type'); 

//七里香https://bkimg.cdn.bcebos.com/pic/d01373f082025aaff92dd92bfaedab64034f1a36?x-bce-process=image/resize,m_lfit,w_268,limit_1/format,f_jpg
//陪你度过https://bkimg.cdn.bcebos.com/pic/b8014a90f603738de4b489caba1bb051f919ec58?x-bce-process=image/resize,m_lfit,w_268,limit_1/format,f_jpg
//十年https://bkimg.cdn.bcebos.com/pic/8644ebf81a4c510f0b02b8bd6c59252dd52aa557?x-bce-process=image/resize,m_lfit,w_268,limit_1/format,f_jpg
// {title:"小幸运", artist:"双笙",cover:"https://p1.music.126.net/fDn4RXX35jVS4diJ1frydA==/18358545649489902.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=409650841.mp3"}, 
// {title:"故梦", artist:"双笙", cover:"https://p1.music.126.net/GZJY3Iz7TacxI3pr4jvQYQ==/18007801439911769.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=409654891.mp3"}, 
// {title:"我的一个道姑朋友", artist:"双笙", cover:"https://p2.music.126.net/_SPItojIVnmpsNsgz8LlMw==/109951164096961308.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=1367452194.mp3"}, 
// {title:"棠梨煎雪", artist:"双笙", cover:"https://p1.music.126.net/73Sxgy165TJk_xNSQ6UYEQ==/109951162895416217.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=468469640.mp3"}, 
// {title:"霜雪千年", artist:"双笙", cover:"https://p1.music.126.net/MlJ3IKOYOGJyrHtCTuLrqg==/18198016951567518.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=409650851.mp3"}, 
// {title:"女孩你为何垫脚尖", artist:"双笙", cover:"https://p1.music.126.net/INL_o40M6oBDaa0sFKK4HA==/109951163021818655.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=504974392.mp3"}, 
// {title:"镜花水月", artist:"双笙", cover:"https://p1.music.126.net/NCSOsqassH7HuPKRUVMCTg==/109951162865987467.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=461922189.mp3"}, 
// {title:"思念是一种病", artist:"张震岳", cover:"https://p1.music.126.net/N61oLy0iLfEkZTHD2j87iA==/18693896697392706.jpg?param=130y130", mp3:"https://music.163.com/song/media/outer/url?id=185700.mp3"},
$music1->poster = 'https://bkimg.cdn.bcebos.com/pic/d01373f082025aaff92dd92bfaedab64034f1a36?x-bce-process=image/resize,m_lfit,w_268,limit_1/format,f_jpg';
$music1->name = '七里香';
$music1->author = '周杰伦';
$music1->src = 'http://freetyst.nf.migu.cn/public/product5th/product35/2019/10/1618/2009%E5%B9%B406%E6%9C%8826%E6%97%A5%E5%8D%9A%E5%B0%94%E6%99%AE%E6%96%AF/%E6%AD%8C%E6%9B%B2%E4%B8%8B%E8%BD%BD/MP3_40_16_Stero/60054701934.mp3?key=4bab10a2135db252&Tim=1596532723593&channelid=00&msisdn=8fab812d69d84497944dd13387ac2282&CI=600547019342600902000006889322&F=000009';
$music1->act = false;

$music2->poster = 'https://bkimg.cdn.bcebos.com/pic/b8014a90f603738de4b489caba1bb051f919ec58?x-bce-process=image/resize,m_lfit,w_268,limit_1/format,f_jpg';
$music2->name = '陪你度过漫长岁月';
$music2->author = '陈奕迅';
$music2->src = 'http://freetyst.nf.migu.cn/public/product08/2018/03/01/2015%E5%B9%B410%E6%9C%8810%E6%97%A520%E7%82%B932%E5%88%86%E7%B4%A7%E6%80%A5%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E6%AD%A3%E4%B8%9C1%E9%A6%96/%E6%AD%8C%E6%9B%B2%E4%B8%8B%E8%BD%BD/MP3_40_16_Stero/%E9%99%AA%E4%BD%A0%E5%BA%A6%E8%BF%87%E6%BC%AB%E9%95%BF%E5%B2%81%E6%9C%88(%E9%99%AA%E5%AE%89%E4%B8%9C%E5%B0%BC%E5%BA%A6%E8%BF%87%E6%BC%AB%E9%95%BF%E5%B2%81%E6%9C%88%E4%B8%BB%E9%A2%98%E6%9B%B2)-%E9%99%88%E5%A5%95%E8%BF%85.mp3?key=fbd99003dea5dd14&Tim=1596533008269&channelid=00&msisdn=254a1d579d8743ee89c26e01f0573009&CI=6005660AE2S2600907000006770896&F=000009';
$music2->act = false;

$music3->poster = 'https://p1.ssl.qhimg.com/dr/270_500_/t016e5ba65dfe45519c.jpg?size=587x590';
$music3->name = '十年';
$music3->author = '陈奕迅';
$music3->src = 'http://freetyst.nf.migu.cn/public/product5th/product35/2019/10/1219/2018%E5%B9%B401%E6%9C%8829%E6%97%A514%E7%82%B911%E5%88%86%E5%86%85%E5%AE%B9%E5%87%86%E5%85%A5%E7%A6%BE%E4%BF%A1%E9%A2%84%E7%95%99999%E9%A6%96/%E6%AD%8C%E6%9B%B2%E4%B8%8B%E8%BD%BD/MP3_40_16_Stero/69910406417.mp3?key=908aa363e201ca9d&Tim=1596533093724&channelid=00&msisdn=8df04e7dd5b64911a1dff142450b76a6&CI=699104064172600908000006799484&F=000009';
$music3->act = false;

$music4->poster = 'https://p1.music.126.net/fDn4RXX35jVS4diJ1frydA==/18358545649489902.jpg?param=130y130';
$music4->name = '小幸运';
$music4->author = '双笙';
$music4->src = 'https://music.163.com/song/media/outer/url?id=409650841.mp3';
$music4->act = false;

$music5->poster = 'https://p1.music.126.net/GZJY3Iz7TacxI3pr4jvQYQ==/18007801439911769.jpg?param=130y130';
$music5->name = '故梦';
$music5->author = '双笙';
$music5->src = 'https://music.163.com/song/media/outer/url?id=409654891.mp3';
$music5->act = false;

$music6->poster = 'https://p2.music.126.net/_SPItojIVnmpsNsgz8LlMw==/109951164096961308.jpg?param=130y130';
$music6->name = '我的一个道姑朋友';
$music6->author = '双笙';
$music6->src = 'https://music.163.com/song/media/outer/url?id=1367452194.mp3';
$music6->act = false;

$music7->poster = 'https://p1.music.126.net/73Sxgy165TJk_xNSQ6UYEQ==/109951162895416217.jpg?param=130y130';
$music7->name = '棠梨煎雪';
$music7->author = '双笙';
$music7->src = 'https://music.163.com/song/media/outer/url?id=468469640.mp3';
$music7->act = false;

$music8->poster = 'https://p1.music.126.net/MlJ3IKOYOGJyrHtCTuLrqg==/18198016951567518.jpg?param=130y130';
$music8->name = '霜雪千年';
$music8->author = '双笙';
$music8->src = 'https://music.163.com/song/media/outer/url?id=409650851.mp3';
$music8->act = false;

$music9->poster = 'https://p1.music.126.net/INL_o40M6oBDaa0sFKK4HA==/109951163021818655.jpg?param=130y130';
$music9->name = '女孩你为何垫脚尖';
$music9->author = '双笙';
$music9->src = 'https://music.163.com/song/media/outer/url?id=504974392.mp3';
$music9->act = false;

$music10->poster = 'https://p1.music.126.net/NCSOsqassH7HuPKRUVMCTg==/109951162865987467.jpg?param=130y130';
$music10->name = '镜花水月';
$music10->author = '双笙';
$music10->src = 'https://music.163.com/song/media/outer/url?id=461922189.mp3';
$music10->act = false;

$music11->poster = 'https://p1.music.126.net/N61oLy0iLfEkZTHD2j87iA==/18693896697392706.jpg?param=130y130';
$music11->name = '思念是一种病';
$music11->author = '张震岳';
$music11->src = 'https://music.163.com/song/media/outer/url?id=185700.mp3';
$music11->act = false;


$music = array($music1,$music2,$music3,$music4,$music5,$music6,$music7,$music8,$music9,$music10,$music11);

print_r(json_encode($music));

?>